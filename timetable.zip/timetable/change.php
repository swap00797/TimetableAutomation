


<?php
session_start();
$username="";
$p=1;
$p1=1;
$p2=1;
$e=0;
$c=0;
$ed=0;
$sem = $_SESSION['sem'];
$day = $_SESSION['day'];
$_SESSION['start']=$_POST["start"];
$start = $_POST["start"];
$a=array();
$option = '';
$b=array();
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");

$strSQL1 =" SELECT DISTINCT Sub_Name FROM teaches WHERE Duration = '1' and Day = '$day' and Start_Time = '$start' and Semester = '$sem'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');

$strSQL1 =" SELECT DISTINCT Sub_Name,Short_Name,Course_Code FROM teaches WHERE Duration = '1' and Day = '$day' and Start_Time = '$start' and Semester = '$sem'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error42');

$strSQL2 =" SELECT DISTINCT Duration FROM teaches WHERE Day = '$day' AND Semester = '$sem' AND Start_Time = '$start'" ;
$result2 = mysqli_query($db,$strSQL2) or die('SQL Error43');
$row = mysqli_fetch_assoc($result2);
$d=$row['Duration'];
$_SESSION['Duration']=$d;
//echo $d;
 $strSQL1="SELECT DISTINCT Sub_Name, Course_Code FROM teaches WHERE Duration='1' AND Semester = '$sem'";
$result1 = mysqli_query($db,$strSQL1) or die('SQL Error44');
// while($row = mysqli_fetch_assoc($result1))
//{
  //$option .= '<option value = "'.$row['Sub_Name, Course_Code'].'">'.$row['Sub_Name, Course_Code'].'</option>';
//}


?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="style.css"/>
     <style>
	
	.tt{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt1{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt2{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt3{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	
    </style>
</head>
<body style="width: 150%; height: 200%;background-color: silver;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="edit.php">Back</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<div style="padding-top:150px;  padding-left: 50px; float = left ; position: absolute;">
  <form >
  	<h2>The subjects selected:</h2>
  				
		<p><input 
			type="text" 
			name="user"
			value="<?php while($row = mysqli_fetch_assoc($result3)){ echo $row['Sub_Name'] ; echo "  "; } ; ?>" 
			size=40
			style="height:50px;
			  width:400px;
			font-size:14pt;"/>
    <br/>
	<br/>
	<h2>The corresponding Faculty:</h2>
		<p><input 
			type="text" 
			name="psw"
			value="<?php while($row = mysqli_fetch_assoc($result4)){ echo $row['Short_Name'] ; echo "  "; } ; ?>"
			size=40
			style="height:50px;
			  width:500px;
			font-size:14pt;"/>
    <br/>
	<br/>
	

  </form>
</div>

<div style="padding-top:75px;padding-left: 850px; position: absolute;">
    	<h2>Select Values to be changed</h2>
		<form action="change2.php" method="post" style="height:30px; width:150px; font-size:14pt;">
			
			<select  name="sub"> 
				<?php
				 while($row = mysqli_fetch_assoc($result1))
				 {
				 	if($row['Sub_Name']=='AA' || $row['Sub_Name']=='SC' || $row['Sub_Name']=='MIS')
				 	{
				 		if($c==0)
				 		{
				 			?>
				 		<option value="ELEC-A">ELEC-A</option>
				 		<?php
				 		$c=1;
				 		}
				 		
				 		
				 	}
				 	elseif($row['Sub_Name']=='GT' || $row['Sub_Name']=='JAVA' || $row['Sub_Name']=='NLP') 
				 	{
				 		if($ed==0)
				 			{
				 				?>
				 		<option value="ELEC-B">ELEC-B</option>
				 		<?php
				 		$ed=1;
				 			}
				 		
				 		
				 	}
				 	elseif($row['Sub_Name']=='BDM' || $row['Sub_Name']=='CCA' || $row['Sub_Name']=='FLGA') 
				 	{
				 		if($ed==0)
				 			{
				 				?>
				 		<option value="ELEC-E">ELEC-E</option>
				 		<?php
				 		$ed=1;
				 			}
				 		
				 		
				 	}
				 	
				 	else
				 	{
				 		?>
				 		<option value="<?php echo $row['Sub_Name']; ?>"><?php echo $row['Sub_Name']; ?></option>
				 	<?php
				 	}
				 	
				 }
				 	?>
			</select>
			<br/>
			<br/>

			
			
			
			<input type="submit" value="Submit">
			<br/>
			<br/>
		
</div>

</body>
</html>