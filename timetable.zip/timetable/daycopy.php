<?php
$query = $_POST['day'] ;
//$fname = explode(" ", 4);
//echo $fname[0];
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
?>
<html>
<head>
   <title>Start_Time table</title>
    <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body style="background-size: auto; background-color: silver;background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="actioncopy2.php">Back</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<H1 style="padding-top: 30px"><FONT COLOR="DARKCYAN"><CENTER><?php echo $query;?> TIMETABLE</FONT></H1>
<table border="2" cellspacing="3" align="center">
<tr>
 <td align="center">
 <td>09:00-10:00
 <td>10:00-11:00
 <td>11:00-11:30
 <td>11:30-12:30
 <td>12:30-01:30
 <td>01:30-02:15
 <td>02:15-03:15
 <td>03:15-04:15
</tr>
<tr>
 <td align="center">
 <td>09:00-10:00
 <td>10:00-11:00
 <td>11:30-12:00
 <td>12:00-01:00
 <td>01:00-02:00
 <td>02:00-02:45
 <td>02:45-03:45
 <td>03:45-04:45
</tr>


<tr>
 <td rowspan="2"align="center">1ST SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '09:00' and Semester = 1";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE  Day = '$query' and Start_Time = '12:30' and  Semester = '1'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '02:15' and  Semester = '1'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '02:15' and  Semester = '1' ";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '02:15' and  Semester = '1' ";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '03:15' and  Semester = '1' ";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '09:00' and  Semester = '1' ";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE Day = '$query' and Start_Time = '12:00' and  Semester = '1' ";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
{
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
 	?>
	<td colspan = "2"  align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
	
		<?php
	
}
	else
	{
$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php
	
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>

	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php

	}


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	
		?>
		<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '1')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}

	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Short_Name'] ; echo $row['Venue'];echo $row['Sub_Name'];echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '1')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">3RD SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = 3)";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br><?php echo $row['Short_Name'] ;?> <br> <?php echo $row['Venue']; ?> <br> <?php echo $row['Sub_Name']; echo ("hi ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '3')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
{
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
 	?>
	<td colspan = "2"  align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php
	
}
	else
	{
$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php
	
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>

	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	}

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '3')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '3')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">5TH SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
{
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	
 	?>
	<td colspan = "2"  align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php
	
}
	else
	{
$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php
	
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>

	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	}

	
	

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '5')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '5')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>



<tr>
 <td rowspan="2"align="center">7TH SEM
 <?php
 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
 //$strSQL2="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 //$strSQL3="SELECT Duration,course.Short_Name from course,teaches,faculty WHERE course.Course_Code = teaches.Course_Code AND faculty.ID = teaches.Faculty_id and Day = '$query' and Start_Time = '02:15' and  faculty.Fname = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}

	 $strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
 	 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
	?>

	<tr>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '09:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '10:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php


	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
{
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	
 	?>
	<td colspan = "2"  align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	
		<?php
	
}
	else
	{
$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '11:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php
	
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:30' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>

	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php

	}

	
	

	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
	<td colspan = "2" align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php
	}
	else
	{
		$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:15' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
			<?php

    	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:15' and  Semester = '7')";
		$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
		//$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '12:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1=" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '01:00' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php



	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '02:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
		<?php




	$strSQL1 =" SELECT DISTINCT Short_Name,Venue,Course_Code,Duration,Sub_Name,Semester from teaches WHERE ( Day = '$query' and Start_Time = '03:45' and  Semester = '7')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php while($row = mysqli_fetch_assoc($result3)){ ?> <br> <?php echo $row['Sub_Name'] ; echo("("); echo $row['Venue'];echo(","); echo $row['Short_Name'];echo(")");echo (" ");} ?><br>
	</tr>
		<?php

 }	
?>




</body>
</html>
