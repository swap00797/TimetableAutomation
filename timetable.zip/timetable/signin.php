<?php
session_start();
$username="";
$p=1;
$p1=1;
$p2=1;
if(isset($_POST['users']) && isset($_POST['psw']) && isset($_POST['cpsw']))
{
		#$pass = $_POST['psw']; 
		$username = $_POST['users'];
		#$cpass = $_POST['cpsw']; 
		if(empty($_POST['users']) || empty($_POST['psw'])){
			$p2=0;

		}
		elseif ($_POST['psw'] != $_POST['cpsw']) {
			$p=0;	 
				
		}
		else
		{
			if($p2==1)
			{
				$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
				$user = $_POST['users'];
				$SESSION['users'] = mysqli_real_escape_string($db, $user);
				$password = (string)$_POST['psw'];
				$strSQL4 =" SELECT * FROM user";
				$user=$SESSION['users'];
				$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
				while($row3= mysqli_fetch_assoc($result3))
				{
				 if(strcmp($row3['username'], $user)==0  && strcmp($row3['password'], $password)==0)
				 {
				 	$p1=0;
				 }
				}
				if($p1==1){
					$strSQL4 ="INSERT INTO `user` (`username`, `password`) VALUES ('$user', '$password')";
					$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
					header("Location:loginagain.php");
				}
			}
			
		}

}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body style="width: 100%; height: 100%;background-color: silver; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
<div style="top: 20%; left: 30%; position: absolute;">
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
  	<p><h3 style="color: white"> Enter the username</h3>
		<p><input 
			type="text" 
			name="users"
			value="<?php echo $username; ?>" 
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
    <br/>
	<br/>
    <p><h3 style="color: white">Enter the password</h3>
		<p><input 
			type="password" 
			name="psw"
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
    <br/>
	<br/>
	<p><h3 style="color: white">Confirm password</h3>
		<p><input 
			type="password" 
			name="cpsw"
			size=40
			style="height:30px;
			  width:300px;
			font-size:14pt;"/>
    <input type="submit" value="Submit">
    <br/>
	<br/>
	<?php
	if ($p2==0) {
		?>
	<h1 style="color: white">Please fill everything<h1>	
		<?php
	}
	if($p==0)
	{
		?>
	<h1 style="color: white">Something's Wrong! Try Again<h1>	
		<?php
	}
	if ($p1==0) {
		?>
	<h1 style="color: white">User ID already exists. Try another one<h1>	
		<?php
	}
	?>
  </form>
</div>
</body>
</html>