<?php
session_start();
$d=$_SESSION["Duration"];
//echo $_SESSION["Duration"];
$sem = $_SESSION['sem'];
$a=$_SESSION['sub'];
$b=$_SESSION['day'];
$c=$_SESSION['start'];
$db = new mysqli('localhost', 'root', '',  'timetable') or die("Unable to connect");
$strSQL1="DELETE FROM  teaches WHERE teaches.Day='$b' AND teaches.Start_Time='$c' AND teaches.Semester='$sem'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error40');
if($a=='ELEC-A')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A1', 'AA','SS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A2','SC', 'KSN', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error42');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5A5', 'MIS', 'SRN', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error43');

	
}

elseif($a=='ELEC-B')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B1','GT', 'SGR', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error44');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B5', 'JAVA','PT', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error45');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS5B6', 'NLP','BMS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error46');

}
elseif($a=='ELEC-E')
{
	$strSQL1=" INSERT INTO teaches (`Course_Code`, `Sub_Name`,`Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E3', 'BDM','GRS', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error47');

	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E4', 'CCA','PT', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error47');

	$strSQL1=" INSERT INTO teaches (`Course_Code`, `Sub_Name`,`Short_Name`, `Day`, `Start_Time`,  `Semester`, `Duration`) VALUES ('12IS7E6', 'FLGA','SGR', '$b', '$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error48');

}

else
{
	$strSQL1="SELECT DISTINCT teaches.Course_Code,teaches.Short_Name,teaches.Venue FROM teaches,faculty WHERE faculty.Short_Name = teaches.Short_Name AND teaches.Sub_Name='$a'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error49');
	$row2 = mysqli_fetch_assoc($result3);
	$course=$row2['Course_Code'];
	$venue=$row2['Venue'];
	$fac=$row2['Short_Name'];
	//echo $course;
	//echo "r";
	//echo $fac;
	//echo $b;
	//echo $c;
	//echo $d;
	if($fac==Null)
	{
		$fac='Null';
	}
	if($venue==Null)
	{
		$venue='Null';
	}
	if($course==Null)
	{
		$course='Null';
	}
	$strSQL1=" INSERT INTO teaches (`Course_Code`,`Sub_Name`, `Short_Name`, `Day`,`Venue`, `Start_Time`,  `Semester`, `Duration`) VALUES ('$course','$a', '$fac', '$b', '$venue','$c',  '$sem', '$d')";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error50');
}
?>

<html>
<head>
   <title></title>
   <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body style="width: 100%; height: 100%;background-color: silver;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;"> <td>
 <div style="padding-top:250px;  padding-left: 200px; float = left ; position: absolute;">
 	<!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="adminlanding.php">Admin</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
<h2>The changes have been made to the database<h2>
	<div/>


<body/>
<html/>
























