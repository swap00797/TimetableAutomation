-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2018 at 05:23 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timetable`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `PNo` bigint(10) DEFAULT NULL,
  `College_ID` varchar(7) NOT NULL,
  `Fname` varchar(25) DEFAULT NULL,
  `DOJ` varchar(10) DEFAULT NULL,
  `Short_Name` varchar(10) NOT NULL DEFAULT 'DEFAULT'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`PNo`, `College_ID`, `Fname`, `DOJ`, `Short_Name`) VALUES
(9538860055, '09T0329', 'Ms.ANISHA B S', '02\\07\\2009', 'ABS'),
(9740384601, '02N0129', 'Mr.AVINASH B V', '03\\01\\2002', 'ABV'),
(9980173921, '11T9391', 'Mr.SRINIVAS B K', '17\\08\\2011', 'BKS'),
(9886332226, '04T0164', 'Dr.SAGAR B M', '23\\08\\2004', 'BMS'),
(9986011689, '12T0424', 'Ms.CHETHANA R MURTHY', '25\\01\\2012', 'CRM'),
(NULL, 'DEF', NULL, NULL, 'DEFAULT'),
(8197922590, '15N0571', 'Mr.DILEEP KUMAR K', '01\\01\\2015', 'DKK'),
(9986997603, '08T0297', 'Ms.PRIYA D', '02\\07\\2008', 'DP'),
(9845979770, '14N0565', 'Ms.GEETHA B G', '01\\12\\2014', 'GBG'),
(9916698388, '10T0353', 'Dr.NAGARAJ G CHOLLI', '16\\07\\2010', 'GCN'),
(9972549576, '02A0136', 'Mr.GANGADHARAIAH K', '17\\09\\2002', 'GK'),
(9448379953, '04T0163', 'Dr.SRINIVASAN G N', '23\\08\\2004', 'GNS'),
(9480091361, '07T0271', 'Ms.SMITHA G R', '22\\10\\2007', 'GRS'),
(9886311120, '05T0171', 'Dr.MAMATHA G S', '24\\01\\2005', 'GSM'),
(9886104374, '05T0198', 'Ms.GEETHA V', '05\\10\\2005', 'GV'),
(9663480603, '15C0606', 'Mr.HARI PRASAD K', '07\\10\\2015', 'HPK'),
(9242147912, '07T0248', 'Ms.KAVITHA S N', '09\\05\\2007', 'KSN'),
(9986073882, '14N0549', 'Ms.LAKSHMI M R', '10\\11\\2014', 'LMR'),
(8792463725, '09N0336', 'Ms.MAHESHWARI D G', '14\\08.2009', 'MDG'),
(8904725680, '14T0542', 'Ms.MERIN MELEET', '11\\08\\2014', 'MM'),
(9972308043, '98T0108', 'Dr.CAUVERY N K', '23\\10\\1998', 'NKC'),
(9902626564, '14T0534', 'Ms.POORNIMA KULKARNI', '01\\08\\2014', 'PK'),
(9632076605, '14T0530', 'Ms.PADMASHREE T', '01\\08\\2014', 'PT'),
(9945164208, '07T0274', 'Ms.REKHA B S', '05\\12\\2007', 'RBS'),
(9902858744, '08A0288', 'Ms.ROOPA E', '03\\04\\2008', 'RE'),
(9886309520, '94T0087', 'Dr.RAMAKANTH KUMAR P', '07\\10\\1994', 'RMP'),
(9886635858, '03T0149', 'Mr.RAJASHEKARA MURTHY S', '26\\08\\2003', 'RMS'),
(9141166455, '15N0579', 'Mr.RAGHAVENDRA N', '16\\02\\2015', 'RN'),
(9844015179, '05T0183', 'Ms.RASHMI R', '14\\07\\2005', 'RR'),
(9845003187, '05T0182', 'Mr.RAGHAVENDRA PRASAD S G', '14\\07\\2005', 'SGR'),
(8892358975, '15C0607', 'Mr.SANJEEV J R', '15\\10\\2015', 'SJR'),
(7795455316, '14T0531', 'Ms.SUSHMITHA N', '01\\08\\2014', 'SN'),
(9448019399, '92T0079', 'Dr.SHANTHARAM NAYAK', '23\\11\\1992', 'SRN'),
(9008485873, '10T0354', 'Ms.SWETHA S', '16\\07\\2010', 'SS'),
(9980131948, '16C0632', 'Mr.SURESH S', '23\\06\\2016', 'SUS'),
(9880154451, '09N0335', 'Mr.UMESH I M', '14\\08\\2009', 'UIM'),
(9538963471, '14T0523', 'Ms.VANISHREE K', '30\\05\\2014', 'VK'),
(9663205233, '16C0633', 'Mr.VINAY K S', '18\\07\\2016', 'VKS'),
(9845965157, '13N0469', 'Mr.VINAY NAYAK', '07\\02\\2013', 'VN'),
(9886891127, '11T0377', 'Ms.YASHODHA T', '21\\02\\2011', 'YT');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `Subject` varchar(55) NOT NULL,
  `Course_Code` varchar(8) NOT NULL,
  `Credits` int(1) DEFAULT NULL,
  `Hours` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`Subject`, `Course_Code`, `Credits`, `Hours`) VALUES
('BRIDGE COURSE MATHS', '12DMA37', NULL, NULL),
('Environmental Science and Biology for Engineers', '12EB42', 4, 4),
('Engineering Materials', '12EM32', 3, 3),
('Java & J2EE (Global-F)', '12GF709', 4, 4),
('Cloud Computing (Global-G)', '12GG708', 3, 3),
('Legal Studies and Professional Ethics', '12HSC73', 2, 2),
('Intellectual property Rights and Entrepreneurship', '12HSI51', 3, 3),
('Management and Organizational Behavior', '12HSM61', 3, 3),
('Data Structure in C (L)', '12IS33', 5, 5),
('Digital Logic Design (L)', '12IS34', 5, 5),
('Object Oriented Programming with C++ (L)', '12IS35', 5, 5),
('Discrete Mathematical Structures', '12IS36', 5, 5),
('Theory of Computation', '12IS43', 4, 4),
('Computer Organization and Architecture', '12IS44', 3, 3),
('Design and Analysis of Algorithms (L)', '12IS45', 5, 5),
('Operating Systems', '12IS46', 3, 3),
('Unix Systems Programming (L)', '12IS49', 5, 5),
('System Software (L)', '12IS52', 5, 5),
('Microprocessors and Multicore Programming (L)', '12IS53', 5, 5),
('Computer Networks and Security', '12IS54', 5, 5),
('Advanced Algroithm', '12IS5A1', 4, 4),
('Soft Computing', '12IS5A2', 4, 4),
('Compiler Design', '12IS5A3', 4, 4),
('File Structures', '12IS5A4', 4, 4),
('Management Information Systems', '12IS5A5', 4, 4),
('Computer Grtaphics', '12IS5A6', 4, 4),
('Graph Theory and Applications', '12IS5B1', 3, 3),
('Information Coding Theory', '12IS5B2', 3, 3),
('Advanced Concepts in operating Systems', '12IS5B3', 3, 3),
('Network Programming', '12IS5B4', 3, 3),
('JAVA and J2EE', '12IS5B5', 3, 3),
('Natural Language Processing with Python', '12IS5B6', 3, 3),
('Software Engineering', '12IS62', 5, 5),
('Computer Networks and Security (L)', '12IS63', 5, 5),
('Database Management Systems (L)', '12IS64', 5, 5),
('Information Security', '12IS6C1', 4, 4),
('Computer System Performance & Analysis', '12IS6C2', 4, 4),
('High Performance Computing', '12IS6C3', 4, 4),
('Image Processing & Computer Vision', '12IS6C4', 4, 4),
('Network Management', '12IS6D2', 3, 3),
('Pattern Recognition', '12IS6D3', 3, 3),
('Mobile Application Development', '12IS6D4', 3, 3),
('Web Programming (L)', '12IS71', 5, 5),
('Software Testing (L)', '12IS72', 5, 5),
('Legal Studies and Professional Ethics for Engineers (*)', '12IS73', 2, 2),
('Human Computer Interaction', '12IS74', 3, 3),
('Wireless Sensor Network', '12IS7E1', 3, 3),
('Enterprise Architecture', '12IS7E2', 3, 3),
('Big Data Analysis', '12IS7E3', 3, 3),
('Cloud Computing and Applications', '12IS7E4', 3, 3),
('Information Retrieval', '12IS7E5', 3, 3),
('Fuzzy Logic and Genetic Applications', '12IS7E6', 3, 3),
('Emerging Technology - NLP', '12ISE65A', 2, 2),
('Emerging Technology - Machine Learing', '12ISE65B', 2, 2),
('Emerging Technology - IOT', '12ISE65C', 2, 2),
('Applied Mathematics-3', '12MA31', 4, 4),
('Applied Mathematics-4', '12MA41', 4, 4),
('Engineering Chemistry (L)', '16CH12', 5, 5),
('Engineering Chemistry (L)', '16CH22', 5, 5),
('Programming in C (L)', '16CS13', 5, 5),
('Programming in C (L)', '16CS23', 5, 5),
('Elements of Civil Engineering', '16CV13', 5, 5),
('Elements of Civil Engineering', '16CV23', 5, 5),
('Basics of Electronic Engineering', '16EC14', 5, 5),
('Basics of Electronic Engineering', '16EC24', 5, 5),
('Elements of Electrical Engineering', '16EE15', 5, 5),
('Elements of Electrical Engineering', '16EE25', 5, 5),
('Constitution of India and Legal Studies for Engineers', '16HSC16', 2, 2),
('Constitution of India and Legal Studies for Engineers', '16HSC26', 2, 2),
('Professional Practice-1', '16HSE16', 0, 2),
('Professional Practice-1', '16HSE26', 0, 2),
('Kannada', '16HSK17', 0, 1),
('Kannada', '16HSK27', 0, 1),
('Engineering Mathematics-1', '16MA11', 5, 5),
('Enginering Mathematics-2', '16MA21', 5, 5),
('Computer Aided Engineering Drawing (L)', '16ME14', 3, 3),
('Basics of Mechanical Engineering (L)', '16ME15', 5, 5),
('Computer Aided Engineering Drawing (L)', '16ME24', 3, 3),
('Basics of Mechanical Engineering (L)', '16ME25', 5, 5),
('Engineering Physics (L)', '16PH12', 5, 5),
('Engineering Physics (L)', '16PH22', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `Timings` varchar(11) NOT NULL,
  `Start_Time` varchar(5) NOT NULL,
  `Duration` decimal(2,1) NOT NULL,
  `Day` varchar(9) NOT NULL,
  `Venue` varchar(12) DEFAULT NULL,
  `Short_Name` varchar(7) NOT NULL,
  `Course_Code` varchar(7) NOT NULL,
  `Sub_Name` varchar(19) DEFAULT NULL,
  `Academic_Year` int(4) DEFAULT NULL,
  `Semester` int(1) NOT NULL,
  `UG/PG` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`Timings`, `Start_Time`, `Duration`, `Day`, `Venue`, `Short_Name`, `Course_Code`, `Sub_Name`, `Academic_Year`, `Semester`, `UG/PG`) VALUES
('02:15-04:45', '02:15', '2.5', 'TUESDAY', 'PIC LAB', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('02:15-04:45', '02:15', '2.5', 'TUESDAY', 'PIC LAB', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('03:45-04:45', '03:45', '1.0', 'MONDAY', 'EC 220', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('09:00-10:00', '09:00', '1.0', 'TUESDAY', 'EC 220', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('09:00-11:30', '09:00', '2.5', 'MONDAY', 'PIC LAB', 'BKS', '16CS13', 'PIC', 2016, 1, 'UG'),
('09:00-11:30', '09:00', '2.5', 'MONDAY', 'PIC LAB', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'ISE 224', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'ISE 106A', 'GRS', '12IS7E3', 'BDM', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'CRC 204', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'ISE 110', 'NKC', '12IS54', 'CN', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'ISE 112A', 'PT', '12IS7E4', 'CCA', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'ISE 304', 'SGR', '12IS7E6', 'FLGA', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'FRIDAY', 'CRC 204', 'VK', '16CS13', 'PIC', 2016, 1, 'UG'),
('10:00-11:00', '10:00', '1.0', 'MONDAY', 'ISE 106A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'MONDAY', 'ISE 109', 'KSN', '12IS5A2', 'SC', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'MONDAY', 'ISE 110', 'RMS ', '12IS5A1', 'AA', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'MONDAY', 'ISE 112A', 'SRN', '12IS5A5', 'MIS', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'THURSDAY', 'ISE 224', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('10:00-11:00', '10:00', '1.0', 'THURSDAY', 'ISE 304', 'BMS ', '12IS5B6', 'NLP', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'THURSDAY', 'ISE 112 B', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('10:00-11:00', '10:00', '1.0', 'THURSDAY', 'ISE 110', 'SGR ', '12IS5B1', 'GT', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'TUESDAY', 'ISE 304', 'BMS ', '12IS5B6', 'NLP', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'TUESDAY', 'ISE 106A', 'RBS', '12GF709', 'JAVA & J2EE', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'TUESDAY', 'ISE 110', 'SGR ', '12IS5B1', 'GT', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'WEDNESDAY', 'ISE 106A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('10:00-11:00', '10:00', '1.0', 'WEDNESDAY', 'ISE 110', 'MM', '12IS53', 'MPMC', 2016, 5, 'UG'),
('10:00-11:00', '10:00', '1.0', 'WEDNESDAY', 'ISE 224', 'PK ', '12IS36', 'DMS', 2016, 3, 'UG'),
('11:30-02:00', '11:30', '2.5', 'THURSDAY', 'PIC LAB', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-02:00', '11:30', '2.5', 'THURSDAY', 'PIC LAB', 'MM', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-12:30', '11:30', '1.0', 'FRIDAY', 'ISE 106A', 'DEFAULT', '12HSC73', 'LSPE', 2016, 7, 'UG'),
('11:30-12:30', '11:30', '1.0', 'FRIDAY', 'ISE 110', 'DEFAULT', '12HSI51', 'EIPR', 2016, 5, 'UG'),
('11:30-12:30', '11:30', '1.0', 'FRIDAY', 'EC 220', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-12:30', '11:30', '1.0', 'MONDAY', 'ISE 106A', 'GRS', '12IS7E3', 'BDM', 2016, 7, 'UG'),
('11:30-12:30', '11:30', '1.0', 'MONDAY', 'ISE 110', 'NKC', '12IS54', 'CN', 2016, 5, 'UG'),
('11:30-12:30', '11:30', '1.0', 'MONDAY', 'ISE 112A', 'PT', '12IS7E4', 'CCA', 2016, 7, 'UG'),
('11:30-12:30', '11:30', '1.0', 'MONDAY', 'ISE 304', 'SGR', '12IS7E6', 'FLGA', 2016, 7, 'UG'),
('11:30-12:30', '11:30', '1.0', 'THURSDAY', 'ISE 224', 'GSM', '12IS34', 'DLD', 2016, 3, 'UG'),
('11:30-12:30', '11:30', '1.0', 'THURSDAY', 'ISE 110', 'NKC', '12IS54', 'CN', 2016, 5, 'UG'),
('11:30-12:30', '11:30', '1.0', 'TUESDAY', 'ISE 106A', 'DEFAULT', '12HSC73', 'LSPE', 2016, 7, 'UG'),
('11:30-12:30', '11:30', '1.0', 'WEDNESDAY', 'ISE 110', 'DEFAULT', '12HSI51', 'EIPR', 2016, 5, 'UG'),
('11:30-12:30', '11:30', '1.0', 'WEDNESDAY', 'ISE 106A', 'GSM', '12GG708', 'CC ', 2016, 7, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'ISE LAB 2A', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'ISE LAB 1A', 'BMS', '12IS33', 'DSC', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'ISE LAB 1A', 'CRM', '12IS33', 'DSC', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'ISE LAB 2A', 'GRS', '12IS35', 'OOP', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'EEE', 'GSM', '12IS34', 'DLD', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'PIC LAB', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'EEE', 'PK', '12IS34', 'DLD', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'FRIDAY', 'PIC LAB', 'SS', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'MONDAY', 'PIC LAB', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'MONDAY', 'PIC LAB', 'VK', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'PIC LAB', 'ABS', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 2A', 'BKS', '12IS52', 'SS', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 2A', 'GCN', '12IS52', 'SS', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 1B', 'GRS', '12IS53', 'M&MP', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'PIC LAB', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 1A', 'MM', '12IS53', 'M&MP', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 1A', 'PT', '12IS53', 'M&MP', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 2B', 'RMS', '12IS52', 'SS', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 1B', 'SGR', '12IS53', 'M&MP', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'TUESDAY', 'ISE LAB 2B', 'SS', '12IS52', 'SS', 2016, 5, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'LAB 2A', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'LAB 1A', 'BMS', '12IS33', 'DSC', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'EEE', 'MM', '12IS34', 'DLD', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'EEE', 'PK', '12IS34', 'DLD', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'LAB 1A', 'PT', '12IS33', 'DSC', 2016, 3, 'UG'),
('11:30-2:00', '11:30', '2.5', 'WEDNESDAY', 'LAB 2A', 'RBS', '12IS35', 'OOP', 2016, 3, 'UG'),
('12:00-1:00', '12:00', '1.0', 'MONDAY', 'ISE 224', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('12:00-1:00', '12:00', '1.0', 'THURSDAY', 'ISE 106A', 'SS ', '12IS74', 'HCI', 2016, 7, 'UG'),
('12:30-01:30', '12:30', '1.0', 'WEDNESDAY', 'EC 220', 'DP', '16CS13', 'PIC', 2016, 1, 'UG'),
('12:30-1:30', '12:30', '1.0', 'FRIDAY', 'ISE 106A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('12:30-1:30', '12:30', '1.0', 'FRIDAY', 'ISE 110', 'MM', '12IS53', 'MPMC', 2016, 5, 'UG'),
('12:30-1:30', '12:30', '1.0', 'MONDAY', 'ISE 110', 'BKS', '12IS52', 'SS', 2016, 5, 'UG'),
('12:30-1:30', '12:30', '1.0', 'MONDAY', 'ISE 112 B', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('12:30-1:30', '12:30', '1.0', 'MONDAY', 'ISE 106A', 'SS ', '12IS74', 'HCI', 2016, 7, 'UG'),
('12:30-1:30', '12:30', '1.0', 'THURSDAY', 'ISE 224', 'CRM ', '12IS33', 'DSC', 2016, 3, 'UG'),
('12:30-1:30', '12:30', '1.0', 'TUESDAY', 'ISE 224', 'PK', '12IS36', 'DMS', 2016, 3, 'UG'),
('12:30-1:30', '12:30', '1.0', 'TUESDAY', 'ISE 106A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('12:30-1:30', '12:30', '1.0', 'WEDNESDAY', 'ISE 106A', 'GSM', '12GG708', 'CC', 2016, 7, 'UG'),
('12:30-1:30', '12:30', '1.0', 'WEDNESDAY', 'ISE 109', 'KSN', '12IS5A2', 'SC', 2016, 5, 'UG'),
('12:30-1:30', '12:30', '1.0', 'WEDNESDAY', 'ISE 110', 'RMS ', '12IS5A1', 'AA', 2016, 5, 'UG'),
('12:30-1:30', '12:30', '1.0', 'WEDNESDAY', 'ISE 112A', 'SRN', '12IS5A5', 'MIS', 2016, 5, 'UG'),
('1:00-2:00', '01:00', '1.0', 'THURSDAY', 'ISE 106A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('1:00-2:00', '1:00', '1.0', 'TUESDAY', 'CRC 204', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-3:15', '02:15', '1.0', 'TUESDAY', 'ISE 106A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('2:15-3:15', '02:15', '1.0', 'WEDNESDAY', 'ISE 106A', 'SS ', '12IS74', 'HCI', 2016, 7, 'UG'),
('2:15-3:15', '2:15', '1.0', 'FRIDAY', 'CRC 204', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-3:15', '2:15', '1.0', 'FRIDAY', 'CRC 204', 'VK', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 2A', 'BKS', '12IS52', 'SS', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 2B', 'GCN', '12IS52', 'SS', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 1A', 'MM', '12IS53', 'M&MP', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 1A', 'PT', '12IS53', 'M&MP', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 2A', 'RBS', '12IS52', 'SS', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 2B', 'RMS', '12IS52', 'SS', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 1B', 'RR', '12IS53', 'M&MP', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'FRIDAY', 'ISE LAB 1B', 'SGR', '12IS53', 'M&MP', 2016, 5, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 1A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 1B', 'MM', '12IS72', 'ST', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 1A', 'PK', '12IS72', 'ST', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 2B', 'PT', '12IS71', 'WP', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 2A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 2A', 'SGR', '12IS71', 'WP', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 1B', 'SRN', '12IS72', 'ST', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'MONDAY', 'ISE LAB 2B', 'SS', '12IS71', 'WP', 2016, 7, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'ISE LAB 2A', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'PIC LAB', 'BKS', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'ISE LAB 1A', 'BMS', '12IS33', 'DSC', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'ISE LAB 1A', 'CRM', '12IS33', 'DSC', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'ISE LAB 2A', 'GRS', '12IS35', 'OOP', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'PIC LAB', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'EEE', 'PK', '12IS34', 'DLD', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'EEE', 'SGR', '12IS34', 'DLD', 2016, 3, 'UG'),
('2:15-4:45', '02:15', '2.5', 'THURSDAY', 'ISE LAB 2A', 'VK', '12IS35', 'OOP', 2016, 3, 'UG'),
('2:15-4:45', '2:15', '2.5', 'TUESDAY', 'PIC LAB', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '2:15', '2.5', 'WEDNESDAY', 'PIC LAB', 'GCN', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '2:15', '2.5', 'WEDNESDAY', 'PIC LAB', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:15-4:45', '2:15', '2.5', 'WEDNESDAY', 'PIC LAB', 'VK', '16CS13', 'PIC', 2016, 1, 'UG'),
('2:45-3:45', '02:45', '1.0', 'FRIDAY', 'ISE 224', 'CRM', '12IS33', 'DSC', 2016, 3, 'UG'),
('2:45-3:45', '02:45', '1.0', 'MONDAY', 'ISE 224', 'GSM', '12IS34', 'DLD', 2016, 3, 'UG'),
('2:45-3:45', '02:45', '1.0', 'THURSDAY', 'ISE 106A', 'RBS', '12GF709', 'JAVA & J2EE', 2016, 7, 'UG'),
('2:45-3:45', '02:45', '1.0', 'TUESDAY', 'ISE 110', 'DEFAULT', '12HSI51', 'EIPR', 2016, 5, 'UG'),
('3:15-4:15', '03:15', '1.0', 'WEDNESDAY', 'ISE 106A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('3:45-4:45', '03:45', '1.0', 'FRIDAY', 'ISE 224', 'PK', '12IS36', 'DMS (T)', 2016, 3, 'UG'),
('3:45-4:45', '03:45', '1.0', 'THURSDAY', 'ISE 106A', 'RBS', '12GF709', 'JAVA & J2EE', 2016, 7, 'UG'),
('3:45-4:45', '03:45', '1.0', 'TUESDAY', 'ISE 110', 'BKS', '12IS52', 'SS', 2016, 5, 'UG'),
('3:45-4:45', '03:45', '1.0', 'TUESDAY', 'ISE 112 B', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('9:00-10:00', '09:00', '1.0', 'FRIDAY', 'ISE 106A', 'GSM', '12GG708', 'CC ', 2016, 7, 'UG'),
('9:00-10:00', '09:00', '1.0', 'FRIDAY', 'ISE 109', 'KSN', '12IS5A2', 'SC', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'FRIDAY', 'ISE 110', 'RMS ', '12IS5A1', 'AA', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'FRIDAY', 'ISE 112A', 'SRN', '12IS5A5', 'MIS', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'MONDAY', 'ISE 304', 'BMS ', '12IS5B6', 'NLP', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'MONDAY', 'ISE 106A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('9:00-10:00', '09:00', '1.0', 'MONDAY', 'ISE 110', 'SGR ', '12IS5B1', 'GT', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'THURSDAY', 'ISE 110', 'MM', '12IS53', 'MPMC', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'THURSDAY', 'ISE 224', 'PK ', '12IS36', 'DMS', 2016, 3, 'UG'),
('9:00-10:00', '09:00', '1.0', 'TUESDAY', 'ISE 224', 'GSM ', '12IS34', 'DLD', 2016, 3, 'UG'),
('9:00-10:00', '09:00', '1.0', 'TUESDAY', 'ISE 110', 'NKC', '12IS54', 'CN', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'TUESDAY', 'ISE 106A', 'RBS', '12GF709', 'JAVA & J2EE', 2016, 7, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 110', 'BKS', '12IS52', 'SS', 2016, 5, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 224', 'CRM ', '12IS33', 'DSC', 2016, 3, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 106A', 'GRS', '12IS7E3', 'BDM', 2016, 7, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 112 B', 'KSN', '16CS13', 'PIC', 2016, 1, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 112A', 'PT', '12IS7E4', 'CCA', 2016, 7, 'UG'),
('9:00-10:00', '09:00', '1.0', 'WEDNESDAY', 'ISE 304', 'SGR', '12IS7E6', 'FLGA', 2016, 7, 'UG'),
('9:00-10:00', '9:00', '1.0', 'THURSDAY', 'CRC 204', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('9:00-10:00', '9:00', '1.0', 'THURSDAY', 'CRC 204', 'VK', '16CS13', 'PIC', 2016, 1, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'LAB 2A', 'ABS', '12IS35', 'OOP', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'LAB 1A', 'CRM', '12IS33', 'DSC', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'EEE', 'GSM', '12IS34', 'DLD', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'EEE', 'MM', '12IS34', 'DLD', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'LAB 2A', 'PK', '12IS35', 'OOP', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'MONDAY', 'LAB 1A', 'SS', '12IS33', 'DSC', 2016, 3, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 1B', 'BKS', '12IS72', 'ST', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 1A', 'GCN', '12IS72', 'ST', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 2A', 'GRS', '12IS71', 'WP', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 2B', 'PT', '12IS71', 'WP', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 1A', 'RMS', '12IS72', 'ST', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 2A', 'RR', '12IS71', 'WP', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 1B', 'SRN', '12IS72', 'ST', 2016, 7, 'UG'),
('9:00-11:30', '09:00', '2.5', 'THURSDAY', 'ISE LAB 2B', 'SS', '12IS71', 'WP', 2016, 7, 'UG'),
('9:00-11:30', '9:00', '2.5', 'TUESDAY', 'PIC LAB', 'GV', '16CS13', 'PIC', 2016, 1, 'UG'),
('9:00-11:30', '9:00', '2.5', 'TUESDAY', 'PIC LAB', 'VK', '16CS13', 'PIC', 2016, 1, 'UG');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `workload`
--

CREATE TABLE `workload` (
  `Name` varchar(67) NOT NULL DEFAULT '',
  `Credits` int(1) DEFAULT NULL,
  `Short_Name` varchar(4) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `workload`
--

INSERT INTO `workload` (`Name`, `Credits`, `Short_Name`) VALUES
('Placement Coordinator ', 2, 'GRS'),
('EMS Coordinator', 1, 'RR'),
('Library', 2, 'MM'),
('TTO', 1, 'KSN'),
('TTO', 1, 'ABS'),
('Test TTO', 1, 'GCN'),
('Test TTO', 1, 'BKS'),
('Website ', 2, 'PT'),
('AICTE + VTU Online Entry', 1, 'CRM '),
('AICTE + VTU Online Entry', 1, 'SS'),
('EDC cell', 0, 'GNS'),
('Project Coordinator ( UG ) ', 0, 'GV'),
('Project Coordinator ( UG ) ', 0, 'SS'),
('Project Coordinator ( PG ) ', 0, 'RBS'),
('NBA Coordinator ( PG) SE', 1, 'SRN '),
('NBA Coordinator ( PG) SE', 1, 'GNS'),
('NBA Coordinator ( PG) IT', 1, 'GNS'),
('NBA Coordinator ( PG) IT', 1, 'RMS'),
('NBA Coordinator (UG)', 1, 'BMS'),
('Department News Letter', 1, 'SRN '),
('Department News Letter', 1, 'SN'),
('BOS', 1, 'SGR'),
('Department TEQIP Incharge', 2, 'GCN '),
('1st sem (Councellor)', 2, 'RR'),
('1st sem (Councellor)', 2, 'GRS'),
('1st sem (Councellor)', 2, 'SS'),
('3rd sem (Councellor)', 2, 'BMS'),
('3rd sem (Councellor)', 2, 'GV'),
('3rd sem (Councellor)', 2, 'VK'),
('3rd sem (Councellor)', 2, 'RMS'),
('5th sem (Councellor)', 2, 'KSN'),
('5th sem (Councellor)', 2, 'SGR'),
('5th sem (Councellor)', 2, 'GCN'),
('5th sem (Councellor)', 2, 'RBS'),
('7th sem (Councellor)', 2, 'GSM'),
('7th sem (Councellor)', 2, 'BKS'),
('7th sem (Councellor)', 2, 'PT'),
('7th sem (Councellor)', 2, 'SN'),
('M.Tech IT (Councellor)', 2, 'ABS '),
('M.Tech SE (Councellor)', 2, 'PK '),
('3rd sem class Teacher', 1, 'PK '),
('5th sem class Teacher', 1, 'MM'),
('7th  sem class Teacher', 1, 'SS'),
('Data Structures in C(Lab Incharge)', 1, 'CRM '),
('Data Structures in C(Lab Incharge)', 1, 'BMS'),
('Digital Logic Design (Lab Incharge)', 1, 'PK'),
('Digital Logic Design (Lab Incharge)', 1, 'GSM'),
('Object Oriented Programming with C++(Lab Incharge)', 1, 'ABS'),
('Object Oriented Programming with C++(Lab Incharge)', 1, 'GRS'),
('System Software(Lab Incharge)', 1, 'BKS'),
('System Software(Lab Incharge)', 1, 'RMS'),
('Microprocessors and Multicore Programming(Lab Incharge)', 1, 'MM'),
('Microprocessors and Multicore Programming(Lab Incharge)', 1, 'SGR'),
('Web Programming(Lab Incharge)', 1, 'RR'),
('Web Programming(Lab Incharge)', 1, 'PT'),
('Software  Testing(Lab Incharge)', 1, 'GCN'),
('Software  Testing(Lab Incharge)', 1, 'SRN '),
('Programming in C(Lab Incharge)', 1, 'KSN'),
('Programming in C(Lab Incharge)', 1, 'GV'),
('Programming in C(Lab Incharge)', 1, 'DP'),
('Software Testing and Data Base Management Systems Lab(Lab Incharge)', 1, 'GNS'),
('Software Testing and Data Base Management Systems Lab(Lab Incharge)', 1, 'DP'),
('Data Compression and ADBMS Lab(Lab Incharge)', 1, 'GNS'),
('Data Compression and ADBMS Lab(Lab Incharge)', 1, 'RBS'),
('EMS Coordinator', 1, 'PK');

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE `year` (
  `Academic Year` int(4) NOT NULL,
  `Semester` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`Academic Year`, `Semester`) VALUES
(2016, 1),
(2016, 3),
(2016, 5),
(2016, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`Short_Name`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`Course_Code`);

--
-- Indexes for table `teaches`
--
ALTER TABLE `teaches`
  ADD PRIMARY KEY (`Timings`,`Start_Time`,`Duration`,`Day`,`Short_Name`,`Course_Code`,`Semester`),
  ADD KEY `subject_fk` (`Course_Code`),
  ADD KEY `year_fk` (`Semester`),
  ADD KEY `faculty_fk` (`Short_Name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `workload`
--
ALTER TABLE `workload`
  ADD PRIMARY KEY (`Name`,`Short_Name`),
  ADD KEY `Short_Name` (`Short_Name`);

--
-- Indexes for table `year`
--
ALTER TABLE `year`
  ADD PRIMARY KEY (`Semester`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `faculty_fk` FOREIGN KEY (`Short_Name`) REFERENCES `faculty` (`Short_Name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_fk` FOREIGN KEY (`Course_Code`) REFERENCES `subjects` (`Course_Code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `year_fk` FOREIGN KEY (`Semester`) REFERENCES `year` (`Semester`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
