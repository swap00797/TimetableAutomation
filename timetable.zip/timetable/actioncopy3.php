<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
        <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
	.outer{
		color: red;
		width: 1500px;
		height: 800px;
		float: right;
		text-align: center;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left: 25px;
	      }
	
	.tt{
		width:250px;
		height:50px;
		margin-top:300px;
		}



	
    </style>
</head>
<body style="background-size: auto; background-color:silver;background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
   <!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <div class = "outer">
		<form action="facultycopy.php" method="post">
			<input type="submit" class="button" value="submit" />
			<select class = "tt" name="fname">
				<option value="PT">Padmashree T</option>
				<option value="RMS">Rajshekar Murthy S</option>
				<option value="GV">Geetha V</option>
				<option value="CRM">Chethana Murthy R</option>
				<option value="BKS">Srinivas B K</option>
				<option value="MM">Merin Meleet</option>
				<option value="SGR">Raghavendra Prasad S</option>
				<option value="GRS">Smitha G R</option>
				<option value="SS">Swetha S</option>
				<option value="GSM">Mamatha G S</option>
				<option value="DP">Priya D</option>
				<option value="RBS">Rekha B S</option>
				<option value="ABS">Anisha B S</option>
				<option value="NKC">Cauvery N K</option>
				<option value="RR">Rashmi R</option>
				<option value="VK">Vanishree K</option>
				<option value="SRN">Shantaram Nayak</option>
				<option value="GCN">Nagaraj G Choli</option>
				<option value="KSN">Kavitha S N</option>
				<option value="GNS">Srinivasan G N</option>
				<option value="BMS">Sagar B M</option>
				<option value="SN">Sushmitha N</option>
				<option value="PK">Poornima K</option>
			</select>
			
		</form>
			

		
</div>
		
		
  	</div>  
</body>
</html>