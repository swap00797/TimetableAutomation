<?php
session_start();
$_SESSION['sub'] = $_POST['sub'];
$a=$_SESSION['sub'];
$b=$_SESSION['day'];
$c=$_SESSION['start'];
//echo $a;
//echo $b;
//echo $c;
//echo $_SESSION["sem"];
$p=0;
$d=0;
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
if($a=='ELEC-A')
{
	$strSQL1 =" SELECT teaches.Sub_Name from subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM teaches,subjects,faculty WHERE teaches.Sub_Name='AA'OR teaches.Sub_Name = 'SC' OR teaches.Sub_Name='MIS'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row2 = mysqli_fetch_assoc($result3);
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'AA'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}


elseif($a=='ELEC-B')
{
	$strSQL1 ="SELECT teaches.Sub_Name from subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM teaches,subjects,faculty WHERE teaches.Sub_Name = 'GT' OR teaches.Sub_Name='JAVA' OR teaches.Sub_Name='NLP'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error401');
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$row2 = mysqli_fetch_assoc($result3);
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'GT'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}

elseif($a=='ELEC-E')
{
	$strSQL1 ="SELECT teaches.Sub_Name from subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name  FROM subjects,teaches WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name IN (SELECT teaches.Sub_Name FROM teaches,subjects,faculty WHERE teaches.Sub_Name = 'BDM' OR teaches.Sub_Name='CCA' OR teaches.Sub_Name='FLGA'))";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error401');
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$row2 = mysqli_fetch_assoc($result3);
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = 'BDM'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}


else
{
	$strSQL1 =" SELECT teaches.Sub_Name from subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code and faculty.Short_Name = teaches.Short_Name and teaches.Day = '$b' and teaches.Start_Time = '$c' and faculty.Short_Name IN (SELECT DISTINCT teaches.Short_Name FROM subjects,teaches,faculty WHERE subjects.Course_Code = teaches.Course_Code AND teaches.Sub_Name='$a')";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error431');
$row2 = mysqli_fetch_assoc($result3);
if (mysqli_num_rows($result3)!=0) {
	$p=1;
}
$x=$row2['Sub_Name'];
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$a'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row3 = mysqli_fetch_assoc($result3);
$strSQL1="SELECT teaches.Semester FROM teaches WHERE teaches.Sub_Name = '$x'";
$result4 = mysqli_query($db,$strSQL1) or die('SQL Error41');
$row4= mysqli_fetch_assoc($result4);
if($p==1 && $row3['Semester']==$row4['Semester'])
{
	$p=0;
}
}




if($_SESSION["Duration"]==1)
{
	$d=1;
}
//if($d==1)
//{
//	$strSQL1 =" SELECT ADDTIME('$_SESSION['start']', '01:00:00')";
//	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
//	$row = mysqli_fetch_assoc($result3);
//}
//else
//{
//	$strSQL1 =" SELECT ADDTIME('$_SESSION['start']', '02:30:00')";
//	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error41');
//	$row = mysqli_fetch_assoc($result3);
//}

if($p==0)
{
	?>
	<html>
<head>
   <title></title>
   <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body style="width: 100%; height: 100%;background-color:silver; height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;"> <td>
    	<!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="adminlanding.php">Back</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
 <div style="padding-top:50px;  padding-left: 100px; float = left ; position: absolute;">
<h2>Do you want to implement the following change to the Database?<h2>
	<div/>
	<br/>
	<br/>
<div style="padding-top:50px;  padding-left: 350px; float = left ; position: absolute;">
<H1><FONT COLOR="DARKCYAN"><CENTER></FONT></H1>
<table border="2" cellspacing="3" align="center">
<tr>
 <td>DAY
 <td>START-TIME
 <td>DURATION
 <td>SUBJECT
 
 
</tr>
<tr>
 <td><?php echo $_SESSION['day']?>
 <td><?php echo $_SESSION['start']?>
 <td><?php echo $_SESSION['Duration']?>
 <td><?php echo $_SESSION['sub']?>

</tr>
<div/>
<div style="  padding-left: 400px; position: absolute;">
	<br/>
<a href= "adminlanding.php"><button style="width: 150px; height: 30px; color: black; border-radius: 15px;">Cancel</button></a>
<form action="update.php" method="post" style="height:30px; width:150px; font-size:14pt;  padding-left: 320px;">
	<input type="submit" value="Submit">

			<br/>
			<br/>
<div/>
</body>
</html>	
<?php
}
else
{
	?>
<html>
<head>
   <title></title>
   <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body bgcolor="skyblue"> <td>
<h3>Cannot make the updation to the time table.<br/><?php echo $row2['Sub_Name'] ;?> who is scheduled to handle <?php echo $a ;?> is already handling the class <?php echo $row2['Sub_Name'] ;?> at <?php echo $c;?> on <?php echo $b;?>.<h3>

</body>
</html>	
<?php
}
?>