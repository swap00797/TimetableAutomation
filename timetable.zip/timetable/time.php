<?php
// Starting session
session_start();
 
// Storing session data
$_SESSION['sem'] = $_POST['semester'];
$_SESSION['day'] = $_POST['day1'];
$username="";
$p=0;
$p1=0;
//$p2=1;
$sem = $_POST['semester'];
$day = $_POST['day1'];
//$start = $_POST['start'];
//$a=array();
//$b=array();
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
$strSQL1 =" SELECT DISTINCT teaches.Duration FROM teaches WHERE teaches.Day = '$day' AND teaches.Semester = '$sem'";
$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
//$row3= mysqli_fetch_assoc($result3)
if (mysqli_num_rows($result3)==1) {
	$p=1;
}
else
{
	$strSQL1 =" SELECT DISTINCT teaches.Duration FROM teaches WHERE teaches.Day = '$day' AND teaches.Semester = '$sem'  AND teaches.Start_Time='09:00'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row3= mysqli_fetch_assoc($result3);
	if($row3['Duration']==2.5)
	{
		$p1=1;
	}
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:lang="kn" dir="ltr">
<head>
    <title>Search</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
	.outer{
		color: red;
		width: 1200px;
		height: 800px;
		float: right;
		text-align: center;
		background: white;
		}
	
	.admin{
		color:white;
		magin-left: 25px;
		margin-top:150px;
	      }
	.exit{
		color:white;
		magin-left:10px;
	      }
	
	.tt1{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt2{
		width:250px;
		height:50px;
		margin-top:25px;
		}
	.tt{
		width:250px;
		height:50px;
		margin-top:25px;
		}
		ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}

	
    </style>
</head>
<body style="width: 100%; height: 100%;background-color: silver;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">
  <!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="edit.php">Back</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <?php
    if($p==1)
    {
    	?>
    	<div style="top: 10%; left: 50%; position: absolute;">
    	<h2>Select starting time</h2>
		<form action="change.php" method="post">
			<select  class="tt2" name="start">
				
				<option value="09:00">09:00</option>
				<option value="10:00">10:00</option>
				<option value="11:30">11:30</option>
				<option value="12:30">12:30</option>
				<option value="02:15">02:15</option>
				<option value="03:15">03:15</option>
			</select>
			<br/>
			<br/>
		<?php
    }
    if($p==0 && $p1==1)
    {
    	?>
    	<div style="top: 10%; left: 50%; position: absolute;">
   		<h2>Select starting time</h2>
		<form action="change.php" method="post">
			<select  class="tt1" name="start">
				
				<option value="12:00">12:00</option>
				<option value="01:00">01:00</option>
				<option value="02:45">02:45</option>
				<option value="03:45">03:45</option>
			</select>
			<br/>
			<br/>
		<?php
    }
    if($p==0 && $p1==0)
    {
    	?>
    <div style="top: 10%; left: 50%; position: absolute;">
    	<h2>Select starting time</h2>
		<form action="change.php" method="post">
			
			<select  class="tt" name="start">
				
				<option value="09:00">09:00</option>
				<option value="10:00">10:00</option>
				<option value="11:30">11:30</option>
				<option value="12:30">12:30</option>
				
			</select>
			<br/>
			<br/>
		<?php	
	}
	?>
	<input type="submit" value="Submit">
			<br/>
			<br/>
		
</div>
		
		
  	</div>  
</body>
</html>

