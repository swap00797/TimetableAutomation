<?php
$query = $_POST['fname'] ;
$fname = explode(" ", $query);
//echo $fname[0];
$db = new mysqli('localhost', 'root', '', 'timetable') or die("Unable to connect");
$strSQL5 ="SELECT Fname from faculty WHERE Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL5) or die('SQL Error5');
 $row1 = mysqli_fetch_assoc($result);
?>
<html>
<head>
   <title>Start_Time table</title>
    <!-- Bootstrap Core CSS -->
    <link href="vendor2/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor2/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

 


</style>
</head>
<body style="background-size: auto; background-color: silver;background-position: center;
    background-repeat: no-repeat;
    background-size: cover;">

  <!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                
                <img alt="Brand" src="img/RV_LOGO.png" style="
                  height: 50px;
                  float: left;
                  ">
                <a class="navbar-brand" href="index.html"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="actioncopy3.php">Back</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

<H1 style="padding-top: 30px"><FONT COLOR="DARKCYAN"><CENTER><?php echo $row1['Fname'];?></FONT></H1>
<table border="3" cellspacing="3" align="center">
<tr>
 <td align="center">
 <td>9:00-10:00
 <td>10:00-11:00
 <td>11:00-11:30
 <td>11:30-12:30
 <td>12:30-1:30
 <td>1:30-2:15
 <td>2:15-3:15
 <td>3:15-4:15
</tr>
<tr>
 <td align="center">
 <td>9:00-10:00
 <td>10:00-11:00
 <td>11:30-12:00
 <td>12:00-1:00
 <td>1:00-2:00
 <td>2:00-2:45
 <td>2:45-3:45
 <td>3:45-4:45
</tr>

<tr>
 <td rowspan="2"align="center">MONDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
$strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 
	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name'];?><br><?php echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<td rowspan="10"align="center">B<br>R<br>E<br>A<br>K
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php
	}
	else{

		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>

	<td rowspan="10"align="center">L<br>U<br>N<br>C<br>H
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'MONDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">TUESDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name'];?><br><?php echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>

		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'TUESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">WEDNESDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name'];?><br><?php echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'WEDNESDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">THURSDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name'];?><br><?php echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'THURSDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>


<tr>
 <td rowspan="2"align="center">FRIDAY
 <?php
 $strSQL1 ="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
 //$strSQL2="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 //$strSQL3="SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
 $result = mysqli_query($db,$strSQL1) or die('SQL Error1');
 //$result2 = mysqli_query($db,$strSQL2) or die('SQL Error2');
 $row1 = mysqli_fetch_assoc($result);
 //$row2 = mysqli_fetch_assoc($result2);
 
 if($row1['Duration'] == 2.5)
 {
 	?>
 	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 	
 	<td align="center"><font color="orange"><br>
 		<?php
    $strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}

	?>
	<tr>
	<td colspan = "2" align="center"><font color="black"><?php echo $row1['Sub_Name'];?><br><?php echo $row1['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php


 }
 else
 {
 	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '09:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '10:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '11:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	
		<?php
	}
	else
	{
		?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php


	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:30' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	<?php
	}
	?>
		<?php

	

	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:15' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	if($row3['Duration'] == 2.5)
	{
		?>
	<td colspan = "2" align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php
	}
	else
	{
		?>
		<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
			<?php

    	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:15' and  Short_Name = '$fname[0]'";
		$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
		$row4 = mysqli_fetch_assoc($result3);
		?>
		<td align="center"><font color="black"><?php echo $row4['Sub_Name']; echo $row4['Venue']; ?><br>
		</tr>
		<?php
	}
	?>
	<td align="center"><font color="pink"><br>
 	<td align="center"><font color="orange"><br>
 		<?php
	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '12:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '01:00' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php



	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '02:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
		<?php




	$strSQL4 =" SELECT Duration,Sub_Name,Venue,Short_Name from teaches WHERE Day = 'FRIDAY' and Start_Time = '03:45' and  Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL4) or die('SQL Error4');
	$row3 = mysqli_fetch_assoc($result3);
	?>
	<td align="center"><font color="black"><?php echo $row3['Sub_Name']; ?> <br> <?php echo $row3['Venue']; ?><br>
	</tr>
		<?php

 }	
?>

</table>
<br>
<br>
<br>
<H3><FONT COLOR="BLACK"><CENTER><?php echo "WORKLOAD";?></FONT></H3>

<table border="1" cellspacing="2" align="center">
<tr>
	<th>Responsibility</th>
	<th>Credits</th>
</tr>


	<?php


	$strSQL1 =" SELECT (2*count(t.Duration)) Theory from teaches as t where t.Duration = '1' and t.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td><font color="black">Theory</font></td>
	<td><font color="black"><?php echo $row4['Theory'];  ?></font></td> <br> 
	</tr>


	<?php


	$strSQL1 =" SELECT (3*count(t.Duration)) Lab from teaches as t where t.Duration = '2.5' and t.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td ><font color="black">Lab</font></td>
	<td ><font color="black"><?php echo $row4['Lab']; ?></font></td> <br> 
	</tr>

	<?php


	$strSQL1 =" SELECT  w.Name,w.Credits from workload as w where w.Short_Name = '$fname[0]'";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	//$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<?php while($row = mysqli_fetch_array($result3)) { ?><td> <?php  echo $row['Name']; ?></td> <td><?php echo $row['Credits']; ?></td></tr> <?php }  ?>
	

	
	

	<?php


	$strSQL1 ="  SELECT  SUM(totalcredits) Total_Credits
FROM
        ( 
            select (2*count(t.Duration)) totalcredits from teaches as t where t.Duration = '1' and t.Short_Name = '$fname[0]' 
            UNION ALL
            select (3*count(t.Duration)) totallcredits from teaches as t where t.Duration = '2.5' and t.Short_Name = '$fname[0]' 
            UNION ALL
            select w.Credits totalcredits from workload as w where w.Short_Name = '$fname[0]'
            )s";
	$result3 = mysqli_query($db,$strSQL1) or die('SQL Error4');
	$row4 = mysqli_fetch_assoc($result3);
	?>
	<tr>	
	<td><font color="black">Total Credits</font></td>
	<td><font color="black"><?php echo $row4['Total_Credits']; ?></font></td> <br> 
	</tr>
</table>

</body>
</html> 
